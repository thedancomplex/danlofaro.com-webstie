kill -9 $(pidof achd)
./remote-ref.sh
./remote-state.sh
