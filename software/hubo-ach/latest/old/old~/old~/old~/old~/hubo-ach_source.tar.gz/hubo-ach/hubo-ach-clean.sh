sudo updatedb
sudo rm -R $(locate hubo | grep /usr/)
sudo rm -R $(locate hubo | grep /etc/)
sudo rm -R $(locate hubo | grep /var/)

